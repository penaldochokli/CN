import socket
import ipaddress

s = socket.socket()
s.bind(('localhost', 12345))
s.listen(1)

print("Server waiting...")
c, addr = s.accept()
print("Connected to client")

ip = c.recv(1024).decode()

network = ipaddress.ip_network(ip + '/24', strict=False)

first = network.network_address + 1
last = network.broadcast_address - 1

result = "First usable IP: " + str(first) + \
         "\nLast usable IP: " + str(last)

c.send(result.encode())

c.close()
s.close()