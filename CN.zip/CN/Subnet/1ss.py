import simpy
import ipaddress

def client(env, server):
    ip = '192.23.2.56'

    print(f"{env.now}: Client sends IP {ip}")

    yield env.timeout(1)

    result = server(ip)

    print(f"{env.now}: {result}")


def server(ip):
    network = ipaddress.ip_network(ip + '/24', strict=False)

    first = network.network_address + 1
    last = network.broadcast_address - 1

    return f"First usable IP: {first}, Last usable IP: {last}"


env = simpy.Environment()

env.process(client(env, server))

env.run()