import socket

c = socket.socket()
c.connect(('localhost', 12345))

ip = input("Enter IP address: ")
c.send(ip.encode())

result = c.recv(1024).decode()
print(result)

c.close()