import socket
import threading

     
def client_handler(client):
    
    n = int(client.recv(1024).decode())

    window = int(client.recv(1024).decode())
    
    frames = list(map(int, client.recv(1024).decode().split()))

    
    lost = int(client.recv(1024).decode())

    print("\nClient connected")
    print("Frames:", frames)
    print("Window Size:", window)

    expected = 0

    for frame in frames:

        
        if frame == lost:
            print("Frame", frame, "Lost")
            print("Discarding remaining frames in window")

            client.send(("TIMEOUT " + str(frame)).encode())

            lost = -1
            continue

        
        if frame == expected:
            print("Frame", frame, "Received")

            
            client.send(("ACK " + str(frame)).encode())

            print("ACK", frame, "Sent")

            expected += 1

        else:
            print("Frame", frame, "Discarded")

    


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(("0.0.0.0", 5034))
server.listen(5)

print("GBN Server Started")
print("Waiting for clients...")

while True:
    client, address = server.accept()

    thread = threading.Thread(
        target=client_handler,
        args=(client,)
    )

    thread.start()
