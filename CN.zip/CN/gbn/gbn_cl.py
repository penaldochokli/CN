import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(("127.0.0.1", 5034))

# Input
n = int(input("Number of Frames: "))
window = int(input("Window Size: "))

frames = list(map(int, input("Frames: ").split()))

lost = int(input("Frame to Lose (-1 for none): "))

# Send information
client.send(str(n).encode())
client.send(str(window).encode())
client.send(" ".join(map(str, frames)).encode())
client.send(str(lost).encode())

print("\nStarting Go-Back-N Transmission...\n")

i = 0

while i < n:

    # Send frames in current window
    end = min(i + window, n)

    print("Sending Frames:", frames[i:end])

    timeout = False

    for j in range(i, end):

        response = client.recv(1024).decode()

        if response.startswith("ACK"):
            print(response)
            i = j + 1

        elif response.startswith("TIMEOUT"):
            print(response)
            timeout = True
            break

    # Retransmission
    if timeout:
        print("Retransmitting Frames:", frames[i:end])

        for j in range(i, end):
            response = client.recv(1024).decode()

            if response.startswith("ACK"):
                print(response)
                i = j + 1

print("\nTransmission Completed Successfully")

client.close()
