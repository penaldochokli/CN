
import simpy
import random
import time

# Simulation parameters
TRANSMISSION_DELAY = 0.1
ACK_DELAY = 0.2
TIMEOUT = 2.0


def receiver(env, channel, ack_channel, lost_frame, stats):
    expected = 0
    loss_occurred = False

    while True:
        seq, send_time = yield channel.get()

        yield env.timeout(TRANSMISSION_DELAY)

        # Simulate loss of the selected frame once
        if seq == lost_frame and not loss_occurred:
            print(f"Time {env.now:.2f}: Frame {seq} lost")
            loss_occurred = True
            stats["lost"] += 1
            continue

        # Go-Back-N receiver accepts only the expected frame
        if seq == expected:
            print(f"Time {env.now:.2f}: Frame {seq} received")

            expected += 1
            stats["received"] += 1

            yield env.timeout(ACK_DELAY)
            yield ack_channel.put(seq)

            stats["acks"] += 1
            print(f"Time {env.now:.2f}: ACK {seq} sent")

        else:
            print(
                f"Time {env.now:.2f}: Frame {seq} discarded; "
                f"expected Frame {expected}"
            )


def sender(env, channel, ack_channel, n, window, frames, stats):
    base = 0

    # Store first transmission time for each frame
    first_sent = {}

    while base < n:
        end = min(base + window, n)

        # Send the current window
        for i in range(base, end):
            if i not in first_sent:
                first_sent[i] = env.now

            print(f"Time {env.now:.2f}: Sending Frame {frames[i]}")

            yield channel.put((frames[i], env.now))

            stats["transmissions"] += 1

            if stats["transmissions"] > n:
                stats["retransmissions"] += 1

            yield env.timeout(TRANSMISSION_DELAY)

        # Wait for ACKs until timeout
        yield env.timeout(TIMEOUT)

        # Collect ACKs received during the waiting period
        acknowledged = set()

        while ack_channel.items:
            ack = yield ack_channel.get()
            acknowledged.add(ack)

        # Advance base through consecutively acknowledged frames
        while base < end and frames[base] in acknowledged:
            stats["total_delay"] += env.now - first_sent[base]
            base += 1

        # If the window is incomplete, Go-Back-N retransmits
        # from the first unacknowledged frame
        if base < end:
            print(
                f"Time {env.now:.2f}: TIMEOUT! "
                f"Retransmitting from Frame {frames[base]}"
            )

    print(f"Time {env.now:.2f}: Transmission completed")


# Main program
n = int(input("Number of frames: "))
window = int(input("Window size: "))

frames = list(map(int, input("Enter frame sequence: ").split()))
lost_frame = int(input("Frame to lose (-1 for none): "))

if (
    n <= 0
    or window <= 0
    or len(frames) != n
    or len(set(frames)) != n
    or (lost_frame != -1 and lost_frame not in frames)
):
    print("Invalid input")

else:
    stats = {
        "transmissions": 0,
        "retransmissions": 0,
        "received": 0,
        "lost": 0,
        "acks": 0,
        "total_delay": 0
    }

    env = simpy.Environment()

    # Communication channels
    channel = simpy.Store(env)
    ack_channel = simpy.Store(env)

    # Start receiver
    env.process(
        receiver(env, channel, ack_channel, lost_frame, stats)
    )

    # Start sender
    sender_process = env.process(
        sender(env, channel, ack_channel, n, window, frames, stats)
    )

    start = time.perf_counter()

    # Run until sender completes
    env.run(until=sender_process)

    execution_time = time.perf_counter() - start

    # Performance report
    print("\n====== PERFORMANCE REPORT ======")
    print("Total frames:", n)
    print("Successful frames:", stats["received"])
    print("ACKs received:", stats["acks"])
    print("Frames lost:", stats["lost"])
    print("Total transmissions:", stats["transmissions"])
    print("Retransmissions:", stats["retransmissions"])

    if n > 0:
        print(
            f"Frame delivery ratio: "
            f"{stats['received'] / n * 100:.2f}%"
        )

    if stats["received"] > 0:
        print(
            f"Average delay: "
            f"{stats['total_delay'] / stats['received']:.2f} seconds"
        )

    if env.now > 0:
        print(
            f"Throughput: "
            f"{stats['received'] / env.now:.2f} frames/second"
        )

    print(f"Simulation time: {env.now:.2f} seconds")
    print(f"Actual execution time: {execution_time:.6f} seconds")
