
import socket
import re
import ipaddress

def valid_mac(mac):
    pattern = r"^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$"
    return re.fullmatch(pattern, mac) is not None

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(("127.0.0.1", 5044))
server.listen(1)

print("===== RARP SERVER =====")

mac = input("Enter registered MAC address: ").strip()
ip = input("Enter IP address for this MAC: ").strip()

if not valid_mac(mac):
    print("Invalid MAC address")
    server.close()
    raise SystemExit

try:
    ipaddress.IPv4Address(ip)
except ValueError:
    print("Invalid IP address")
    server.close()
    raise SystemExit

mapping_table = {mac.lower(): ip}

print("\nRARP Mapping Table:")
for m, address in mapping_table.items():
    print(m, "->", address)

print("\nWaiting for RARP Client...")

conn, client_address = server.accept()
print("Client connected:", client_address)

client_mac = conn.recv(1024).decode().strip().lower()

print("\nRARP Request Received")
print("Client MAC:", client_mac)

if not valid_mac(client_mac):
    reply = "FAILED|Invalid MAC address"
elif client_mac in mapping_table:
    reply = "SUCCESS|" + mapping_table[client_mac]
    print("MAC address found")
    print("Assigned IP:", mapping_table[client_mac])
else:
    reply = "FAILED|MAC address not found"
    print("MAC address not found")

conn.sendall(reply.encode())

print("\nRARP Reply Sent:")
print(reply)

conn.close()
server.close()

print("RARP Server Closed")
