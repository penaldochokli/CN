
import simpy
import random

# RARP Mapping Table
mapping_table = {
    "AA-BB-CC-DD-EE-FF": "192.168.1.10",
    "11-22-33-44-55-66": "192.168.1.20"
}

# Statistics
total_requests = 0
successful_requests = 0
failed_requests = 0
total_delay = 0

def rarp_client(env, mac, server):
    global total_requests, successful_requests, failed_requests, total_delay

    print(f"{env.now:.2f}s: Client with MAC {mac} started")

    start_time = env.now
    total_requests += 1

    print(f"{env.now:.2f}s: RARP Request sent for MAC {mac}")

    # Network transmission delay
    yield env.timeout(random.uniform(1, 3))

    # Send request to server
    result = yield env.process(rarp_server(env, mac))

    # Reply transmission delay
    yield env.timeout(random.uniform(1, 2))

    total_delay += env.now - start_time

    if result:
        successful_requests += 1
        print(f"{env.now:.2f}s: RARP Reply received: IP = {result}")
    else:
        failed_requests += 1
        print(f"{env.now:.2f}s: RARP Failed: MAC address not found")

def rarp_server(env, mac):
    print(f"{env.now:.2f}s: Server received RARP request")

    # Server processing delay
    yield env.timeout(1)

    if mac in mapping_table:
        ip = mapping_table[mac]
        print(f"{env.now:.2f}s: Server found IP {ip}")
        return ip
    else:
        print(f"{env.now:.2f}s: Server could not find MAC")
        return None

# Create simulation environment
env = simpy.Environment()

# Create clients
clients = [
    "AA-BB-CC-DD-EE-FF",
    "11-22-33-44-55-66",
    "77-88-99-AA-BB-CC"
]

for mac in clients:
    env.process(rarp_client(env, mac, None))

# Run simulation
env.run()

# Display statistics
print("\n===== RARP SIMULATION RESULTS =====")
print("Total Requests:", total_requests)
print("Successful Requests:", successful_requests)
print("Failed Requests:", failed_requests)

if total_requests > 0:
    print("Success Rate:", round(successful_requests / total_requests * 100, 2), "%")
    print("Failure Rate:", round(failed_requests / total_requests * 100, 2), "%")
    print("Average Response Time:", round(total_delay / total_requests, 2), "seconds")
