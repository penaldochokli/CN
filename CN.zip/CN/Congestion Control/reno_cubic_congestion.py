import simpy
import random
import math
import matplotlib.pyplot as plt


class TCPSimulation:
    def __init__(self, env, data_mb, segment_kb, bandwidth_mbps,
                 rtt_ms, loss_prob, algorithm, initial_cwnd=1):

        self.env = env
        self.algorithm = algorithm.upper()

        self.total_bytes = int(data_mb * 1024 * 1024)
        self.segment_size = int(segment_kb * 1024)
        self.total_segments = math.ceil(
            self.total_bytes / self.segment_size
        )

        self.bandwidth = bandwidth_mbps * 1_000_000
        self.base_rtt = rtt_ms / 1000
        self.loss_prob = loss_prob / 100

        self.cwnd = float(initial_cwnd)
        self.ssthresh = 64.0
        self.max_cwnd = self.cwnd

        self.next_segment = 0
        self.pending = []
        self.attempts = {}

        self.packets_transmitted = 0
        self.packets_lost = 0
        self.acks_received = 0
        self.retransmissions = 0
        self.delivered_bytes = 0

        self.cwnd_history = []
        self.rtt_history = []
        self.throughput_history = []
        self.time_history = []

        self.bw_estimate = self.bandwidth
        self.min_rtt = self.base_rtt
        self.round_count = 0

        self.env.process(self.sender())

    def sender(self):
        while self.delivered_bytes < self.total_bytes:

            self.round_count += 1

            # BBR estimates bandwidth and maintains a BDP-based window.
            if self.algorithm == "BBR":
                bdp = (
                    self.bw_estimate * self.min_rtt
                    / (8 * self.segment_size)
                )
                self.cwnd = max(4.0, 2.0 * bdp)

            # Fill the congestion window with segments.
            window = max(1, int(self.cwnd))

            while (
                len(self.pending) < window
                and self.next_segment < self.total_segments
            ):
                self.pending.append(self.next_segment)
                self.next_segment += 1

            if not self.pending:
                break

            batch = self.pending[:window]
            self.pending = self.pending[window:]

            successful = []
            lost = []

            batch_bytes = sum(
                min(
                    self.segment_size,
                    self.total_bytes - sid * self.segment_size
                )
                for sid in batch
            )

            # Simulate segment transmission and packet loss.
            for sid in batch:
                self.packets_transmitted += 1

                if self.attempts.get(sid, 0) > 0:
                    self.retransmissions += 1

                self.attempts[sid] = self.attempts.get(sid, 0) + 1

                if random.random() < self.loss_prob:
                    lost.append(sid)
                    self.packets_lost += 1
                else:
                    successful.append(sid)

            # Transmission delay + propagation RTT.
            transmission_delay = batch_bytes * 8 / self.bandwidth
            actual_rtt = self.base_rtt * random.uniform(0.95, 1.05)

            yield self.env.timeout(
                transmission_delay + actual_rtt
            )

            # Receiver generates ACKs for successful segments.
            self.acks_received += len(successful)

            for sid in successful:
                self.delivered_bytes += min(
                    self.segment_size,
                    self.total_bytes - sid * self.segment_size
                )

            # Lost segments must be retransmitted.
            self.pending.extend(lost)

            # Update congestion control.
            if self.algorithm == "RENO":

                if lost:
                    self.ssthresh = max(2, self.cwnd / 2)
                    self.cwnd = self.ssthresh
                elif self.cwnd < self.ssthresh:
                    self.cwnd *= 2
                else:
                    self.cwnd += 1

            elif self.algorithm == "CUBIC":

                if lost:
                    self.max_cwnd = max(
                        self.max_cwnd, self.cwnd
                    )
                    self.cwnd = max(2, self.cwnd * 0.7)
                else:
                    # Simplified cubic-like window growth.
                    self.cwnd += max(
                        0.1,
                        0.4 * math.sqrt(self.cwnd)
                    )

            elif self.algorithm == "BBR":

                # Estimate bandwidth from delivered data.
                if actual_rtt > 0:
                    sample_bw = (
                        len(successful) * self.segment_size * 8
                        / actual_rtt
                    )

                    self.bw_estimate = max(
                        self.bw_estimate * 0.9,
                        sample_bw
                    )

                self.min_rtt = min(
                    self.min_rtt, actual_rtt
                )

            # Record performance measurements.
            elapsed = self.env.now

            throughput = (
                self.delivered_bytes * 8
                / elapsed / 1_000_000
                if elapsed > 0 else 0
            )

            self.time_history.append(elapsed)
            self.cwnd_history.append(self.cwnd)
            self.rtt_history.append(actual_rtt * 1000)
            self.throughput_history.append(throughput)

            # Avoid an excessively large window.
            self.cwnd = min(
                max(self.cwnd, 1),
                200
            )

    def results(self):
        elapsed = self.env.now

        throughput = (
            self.delivered_bytes * 8 / elapsed / 1_000_000
            if elapsed > 0 else 0
        )

        avg_rtt = (
            sum(self.rtt_history) / len(self.rtt_history)
            if self.rtt_history else 0
        )

        avg_cwnd = (
            sum(self.cwnd_history) / len(self.cwnd_history)
            if self.cwnd_history else 0
        )

        return {
            "Algorithm": self.algorithm,
            "Throughput (Mbps)": round(throughput, 2),
            "Average RTT (ms)": round(avg_rtt, 2),
            "Packets Lost": self.packets_lost,
            "Retransmissions": self.retransmissions,
            "Average cwnd (segments)": round(avg_cwnd, 2),
            "Completion Time (s)": round(elapsed, 3)
        }


def run_simulation(data_mb, segment_kb, bandwidth_mbps,
                   rtt_ms, loss_prob, algorithm, initial_cwnd=1):

    env = simpy.Environment()

    tcp = TCPSimulation(
        env,
        data_mb,
        segment_kb,
        bandwidth_mbps,
        rtt_ms,
        loss_prob,
        algorithm,
        initial_cwnd
    )

    env.run()

    return tcp


# ---------------- MAIN PROGRAM ----------------

print("\nTCP CONGESTION CONTROL SIMULATION")
print("1. TCP Reno")
print("2. TCP CUBIC")
print("3. TCP BBR")
print("4. Compare all three algorithms")

choice = int(input("Enter choice: "))

data_mb = float(input("Total data (MB): "))
segment_kb = float(input("Segment size (KB): "))
bandwidth_mbps = float(input("Bandwidth (Mbps): "))
rtt_ms = float(input("Base RTT (ms): "))
loss_prob = float(input("Packet loss probability (%): "))
initial_cwnd = int(input("Initial congestion window (segments): "))

algorithms = {
    1: ["RENO"],
    2: ["CUBIC"],
    3: ["BBR"],
    4: ["RENO", "CUBIC", "BBR"]
}

if choice not in algorithms:
    print("Invalid choice!")
    raise SystemExit

random.seed(42)

results = []
simulations = []

for algorithm in algorithms[choice]:

    print(f"\nRunning TCP {algorithm}...")

    tcp = run_simulation(
        data_mb,
        segment_kb,
        bandwidth_mbps,
        rtt_ms,
        loss_prob,
        algorithm,
        initial_cwnd
    )

    simulations.append(tcp)
    results.append(tcp.results())

    print("\nAlgorithm:", algorithm)
    for key, value in tcp.results().items():
        print(f"{key}: {value}")


# ---------------- COMPARISON TABLE ----------------

if choice == 4:
    print("\n========== COMPARISON ==========")

    headers = list(results[0].keys())
    print(" | ".join(headers))
    print("-" * 110)

    for result in results:
        print(" | ".join(str(result[h]) for h in headers))


# ---------------- GRAPH 1: CWND ----------------

plt.figure(figsize=(9, 5))

for tcp in simulations:
    plt.plot(
        tcp.time_history,
        tcp.cwnd_history,
        label=tcp.algorithm
    )

plt.xlabel("Simulation Time (seconds)")
plt.ylabel("Congestion Window (segments)")
plt.title("Time vs Congestion Window")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


# ---------------- GRAPH 2: THROUGHPUT ----------------

plt.figure(figsize=(9, 5))

for tcp in simulations:
    plt.plot(
        tcp.time_history,
        tcp.throughput_history,
        label=tcp.algorithm
    )

plt.xlabel("Simulation Time (seconds)")
plt.ylabel("Throughput (Mbps)")
plt.title("Time vs Throughput")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


# ---------------- GRAPH 3: RTT ----------------

plt.figure(figsize=(9, 5))

for tcp in simulations:
    plt.plot(
        tcp.time_history,
        tcp.rtt_history,
        label=tcp.algorithm
    )

plt.xlabel("Simulation Time (seconds)")
plt.ylabel("RTT (ms)")
plt.title("Time vs RTT")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()