import socket
import threading


def check_data(data, checksum):
    total = 0

    # Add all bytes
    for byte in data:
        total += byte

    # Handle carry
    total = (total & 255) + (total >> 8)
    total = (total & 255) + (total >> 8)

    # Calculate checksum
    result = (~total) & 255

    return result == checksum


def client_handler(client, address):
    print("Client connected:", address)

    try:
        # Receive data
        data = client.recv(1024)

        # Receive checksum
        checksum_data = client.recv(1024).decode().strip()
        checksum = int(checksum_data)

        # Check data
        if check_data(data, checksum):
            response = "Valid - No Error Detected"
        else:
            response = "Corrupted - Error Detected"

        # Send result to client
        client.sendall(response.encode())

    except Exception as e:
        print("Error:", e)

    finally:
        client.close()
        print("Client disconnected:", address)


# Create TCP socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind server
server.bind(("127.0.0.1", 5000))

# Listen for multiple clients
server.listen(5)

print("Checksum Server Started")
print("Server IP: 127.0.0.1")
print("Server Port: 5001")
print("Waiting for clients...")

while True:
    client, address = server.accept()

    # Create a new thread for each client
    thread = threading.Thread(
        target=client_handler,
        args=(client, address)
    )


    thread.start()