import simpy, random
random.seed(8)

def send_mail(env, stats, n):
    start = env.now
    print(f"{env.now:.1f}s Client {n}: connect, EHLO, MAIL FROM, RCPT TO")
    yield env.timeout(random.uniform(0.2, 0.5))
    print(f"{env.now:.1f}s Client {n}: DATA (sending email)")
    yield env.timeout(random.uniform(0.4, 1.0))
    print(f"{env.now:.1f}s Client {n}: server returns 250 accepted")
    stats["ok"] += 1; stats["delay"] += env.now-start

env = simpy.Environment(); stats = {"ok": 0, "delay": 0.0}
for n in range(1, 4): env.process(send_mail(env, stats, n))
env.run()
print("Emails accepted:", stats["ok"], "Average completion time:", round(stats["delay"]/stats["ok"], 2), "s")
