import socket

HOST, PORT = "127.0.0.1", 2525  # demo port; SMTP commonly uses 25
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT)); s.listen(1)
    print(f"SMTP demo server listening on {HOST}:{PORT}")
    conn, addr = s.accept()
    with conn:
        f = conn.makefile("rwb")
        f.write(b"220 SMTP demo ready\r\n"); f.flush()
        in_data = False; message = []
        while True:
            line = f.readline().decode(errors="replace").rstrip("\r\n")
            if not line: break
            upper = line.upper()
            if in_data:
                if line == ".":
                    print("Received email:\n" + "\n".join(message))
                    f.write(b"250 message accepted\r\n"); f.flush()
                    in_data = False; message = []
                else: message.append(line)
            elif upper.startswith("EHLO") or upper.startswith("HELO"):
                f.write(b"250 Hello\r\n")
            elif upper.startswith("MAIL FROM:"):
                f.write(b"250 sender accepted\r\n")
            elif upper.startswith("RCPT TO:"):
                f.write(b"250 recipient accepted\r\n")
            elif upper == "DATA":
                in_data = True; f.write(b"354 end with dot on a line\r\n")
            elif upper == "QUIT":
                f.write(b"221 bye\r\n"); f.flush(); break
            else:
                f.write(b"250 OK (demo)\r\n")
            f.flush()
