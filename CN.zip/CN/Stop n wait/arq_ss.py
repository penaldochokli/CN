import simpy
import random

def sender(env):
    frames = ["Frame 1", "Frame 2", "Frame 3"]

    for frame in frames:
        while True:
            print(f"{env.now}: Sending {frame}")

            yield env.timeout(2)

            # Simulate ACK loss
            if random.random() < 0.4:
                print(f"{env.now}: ACK lost! Retransmitting...")
                yield env.timeout(3)
            else:
                print(f"{env.now}: ACK received for {frame}")
                break

env = simpy.Environment()
env.process(sender(env))
env.run()