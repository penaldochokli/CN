import socket
import threading

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_address = ("127.0.0.1", 5000)

username = input("Enter your username: ")
client.sendto(username.encode(), server_address)

print("Connected to server.")

def receive():
    while True:
        try:
            data, address = client.recvfrom(1024)
            print("\n" + data.decode())
        except:
            break


threading.Thread(target=receive, daemon=True).start()

while True:
    message = input(username + ": ")
    client.sendto(message.encode(), server_address)

    if message.lower() == "exit":
        print("Closing client...")
        break

client.close()
