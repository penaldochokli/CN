import socket
import threading

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 5000))

username = input("Enter your username: ")
client.sendall(username.encode())

print("Connected to server.")

def receive():
    while True:
        try:
            data = client.recv(1024).decode()

            if not data:
                break
            print("\n" + data)
        except:
            break

threading.Thread(target=receive, daemon=True).start()

while True:
    message = input(username + ": ")
    client.sendall(message.encode())

    if message.lower() == "exit":
        print("Closing client...")
        break

client.close()
