import socket
import threading

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("127.0.0.1", 5000))
server.listen()

clients = {}

print("Server waiting for connections...")

def broadcast(message, sender):
    for client in clients:
        if client != sender:
            client.sendall(message.encode())


def handle_client(client_socket, client_address):
    username = client_socket.recv(1024).decode()
    clients[client_socket] = username

    print(username, "connected")

    while True:
        data = client_socket.recv(1024).decode()

        if not data or data.lower() == "exit":
            break

        message = username + ": " + data
        print(message)
        broadcast(message, client_socket)

    del clients[client_socket]
    client_socket.close()
    print(username, "disconnected")

while True:
    client_socket, client_address = server.accept()

    threading.Thread(
        target=handle_client,
        args=(client_socket, client_address),
        daemon=True
    ).start()