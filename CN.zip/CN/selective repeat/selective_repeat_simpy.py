# Selective Repeat ARQ - SimPy Simulation
# Install first: pip install simpy
# Run: python selective_repeat_simpy.py
# This is a discrete-event simulation; it does not use real sockets.

import random
import simpy

TOTAL_FRAMES = 12
WINDOW_SIZE = 4
TIMEOUT = 4.0
PROPAGATION_DELAY = 1.0
ACK_DELAY = 1.0
LOSS_PROBABILITY = 0.20
SEED = 7

def sender(env, receiver, stats):
    base = 0
    next_seq = 0
    acked = [False] * TOTAL_FRAMES
    timer = {}
    transmissions = 0
    print(f"{env.now:5.1f}s | Sender starts: frames={TOTAL_FRAMES}, window={WINDOW_SIZE}")

    while not all(acked):
        # Send new frames that fit into the current sender window.
        while next_seq < TOTAL_FRAMES and next_seq < base + WINDOW_SIZE:
            transmissions += 1
            stats["transmissions"] += 1
            timer[next_seq] = env.now
            print(f"{env.now:5.1f}s | SEND frame {next_seq}")
            env.process(channel_to_receiver(env, receiver, next_seq, stats))
            next_seq += 1

        # Wait for an ACK event or a short tick to check individual timers.
        yield env.timeout(0.5)

        # Selectively retransmit only expired, unacknowledged frames.
        for seq in range(base, min(base + WINDOW_SIZE, TOTAL_FRAMES)):
            if not acked[seq] and seq in timer and env.now - timer[seq] >= TIMEOUT:
                transmissions += 1
                stats["transmissions"] += 1
                stats["retransmissions"] += 1
                timer[seq] = env.now
                print(f"{env.now:5.1f}s | TIMEOUT -> retransmit frame {seq}")
                env.process(channel_to_receiver(env, receiver, seq, stats))

        # ACKs are stored by receiver in stats; sender processes them here.
        for seq in list(stats["pending_acks"]):
            if 0 <= seq < TOTAL_FRAMES:
                acked[seq] = True
                timer.pop(seq, None)
                stats["pending_acks"].remove(seq)
                print(f"{env.now:5.1f}s | ACK {seq} accepted by sender")

        while base < TOTAL_FRAMES and acked[base]:
            base += 1

    stats["completion_time"] = env.now
    print(f"{env.now:5.1f}s | All frames acknowledged.")

def channel_to_receiver(env, receiver, seq, stats):
    yield env.timeout(PROPAGATION_DELAY)
    if random.random() < LOSS_PROBABILITY:
        stats["lost_frames"] += 1
        print(f"{env.now:5.1f}s | CHANNEL LOST frame {seq}")
        return
    yield env.process(receiver.receive(seq, stats))

class Receiver:
    def __init__(self, env):
        self.env = env
        self.expected = 0
        self.buffer = {}
        self.delivered = []

    def receive(self, seq, stats):
        print(f"{self.env.now:5.1f}s | Receiver got frame {seq}")
        # Every received frame is individually acknowledged, including duplicates.
        yield self.env.timeout(ACK_DELAY)
        stats["pending_acks"].append(seq)

        if seq not in self.delivered and seq not in self.buffer:
            self.buffer[seq] = True

        while self.expected in self.buffer:
            self.buffer.pop(self.expected)
            self.delivered.append(self.expected)
            print(f"{self.env.now:5.1f}s | Receiver delivers frame {self.expected}")
            self.expected += 1

def main():
    random.seed(SEED)
    env = simpy.Environment()
    receiver = Receiver(env)
    stats = {
        "transmissions": 0,
        "retransmissions": 0,
        "lost_frames": 0,
        "pending_acks": [],
        "completion_time": 0.0,
    }
    env.process(sender(env, receiver, stats))
    env.run(until=200)

    delivered = len(receiver.delivered)
    sent = stats["transmissions"]
    print("\n========== PERFORMANCE SUMMARY ==========")
    print(f"Frames delivered in order : {delivered}/{TOTAL_FRAMES}")
    print(f"Total transmissions       : {sent}")
    print(f"Retransmissions           : {stats['retransmissions']}")
    print(f"Frames lost in channel    : {stats['lost_frames']}")
    print(f"Completion time           : {stats['completion_time']:.1f} simulated seconds")
    print(f"Delivery ratio            : {delivered / TOTAL_FRAMES * 100:.1f}%")
    print(f"Transmission efficiency   : {TOTAL_FRAMES / sent * 100:.1f}%" if sent else "Transmission efficiency: N/A")
    if delivered < TOTAL_FRAMES:
        print("Simulation stopped before completion; increase the env.run limit or check the model.")

if __name__ == "__main__":
    main()
