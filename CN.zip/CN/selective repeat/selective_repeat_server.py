# Selective Repeat ARQ - UDP Server
# Run: python selective_repeat_server.py
# Educational localhost demo. The server receives frames, acknowledges each frame
# individually, buffers out-of-order frames, and delivers them in sequence.

import socket

HOST = "127.0.0.1"
PORT = 5005
TOTAL_FRAMES = 10
WINDOW_SIZE = 4

def main():
    expected = 0
    received = set()
    buffer = {}
    delivered = []

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind((HOST, PORT))
        print(f"Selective Repeat receiver listening on {HOST}:{PORT}")
        print(f"Expected frames: 0 to {TOTAL_FRAMES - 1}; window size: {WINDOW_SIZE}")
        print("Start the client in another terminal.\n")

        while len(delivered) < TOTAL_FRAMES:
            packet, client_addr = server.recvfrom(2048)
            message = packet.decode(errors="replace").strip()
            parts = message.split("|")

            if len(parts) != 3 or parts[0] != "DATA":
                print(f"Ignored malformed packet: {message}")
                continue

            try:
                seq = int(parts[1])
                payload = parts[2]
            except ValueError:
                print(f"Ignored invalid frame: {message}")
                continue

            if not 0 <= seq < TOTAL_FRAMES:
                continue

            # ACK every correctly received frame, including duplicates.
            server.sendto(f"ACK|{seq}".encode(), client_addr)

            if seq in received:
                print(f"Duplicate frame {seq} received; ACK {seq} resent.")
                continue

            received.add(seq)
            buffer[seq] = payload
            print(f"Received frame {seq}: {payload}; sent ACK {seq}.")

            # Deliver buffered frames in order whenever the next expected frame exists.
            while expected in buffer:
                delivered.append(buffer.pop(expected))
                print(f"  Delivered frame {expected} in order.")
                expected += 1

        print("\nAll frames delivered in order:")
        for i, payload in enumerate(delivered):
            print(f"  Frame {i}: {payload}")
        print("Receiver finished.")

if __name__ == "__main__":
    main()
