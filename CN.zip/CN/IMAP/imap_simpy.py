import simpy, random
random.seed(9)

def read_mail(env, stats, n):
    start = env.now
    print(f"{env.now:.1f}s Client {n}: LOGIN and SELECT INBOX")
    yield env.timeout(random.uniform(0.2, 0.5))
    print(f"{env.now:.1f}s Client {n}: FETCH message")
    yield env.timeout(random.uniform(0.3, 0.7))
    print(f"{env.now:.1f}s Client {n}: message read; LOGOUT")
    stats["ok"] += 1; stats["delay"] += env.now-start

env = simpy.Environment(); stats = {"ok": 0, "delay": 0.0}
for n in range(1, 4): env.process(read_mail(env, stats, n))
env.run()
print("Completed sessions:", stats["ok"], "Average session time:", round(stats["delay"]/stats["ok"], 2), "s")
