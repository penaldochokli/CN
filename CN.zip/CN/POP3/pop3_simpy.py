import simpy, random
random.seed(7)

def client(env, stats):
    start = env.now
    print(f"{env.now:.1f}s POP3 client: connect and authenticate")
    yield env.timeout(random.uniform(0.2, 0.6))
    print(f"{env.now:.1f}s POP3 client: STAT/LIST request")
    yield env.timeout(random.uniform(0.2, 0.5))
    print(f"{env.now:.1f}s POP3 client: RETR message")
    yield env.timeout(random.uniform(0.3, 0.8))
    stats["ok"] += 1
    stats["delay"] += env.now - start
    print(f"{env.now:.1f}s POP3 client: message received, QUIT")

env = simpy.Environment(); stats = {"ok": 0, "delay": 0.0}
for _ in range(3): env.process(client(env, stats))
env.run()
print("Requests:", stats["ok"], "Average response time:", round(stats["delay"]/stats["ok"], 2), "s")
