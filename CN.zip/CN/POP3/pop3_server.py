import socket

HOST, PORT = "127.0.0.1", 1110  # use 110 only with suitable permissions
MAILS = ["From: alice@example.com\nSubject: Lab\n\nHello from POP3 demo."]

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT))
    s.listen(1)
    print(f"POP3 demo server listening on {HOST}:{PORT}")
    conn, addr = s.accept()
    with conn:
        print("Client:", addr)
        conn.sendall(b"+OK POP3 demo ready\r\n")
        f = conn.makefile("rwb")
        while True:
            line = f.readline().decode(errors="replace").strip()
            if not line:
                break
            parts = line.split(maxsplit=1)
            cmd = parts[0].upper()
            if cmd == "USER":
                response = b"+OK user accepted\r\n"
            elif cmd == "PASS":
                response = b"+OK login accepted (demo only)\r\n"
            elif cmd == "STAT":
                response = f"+OK {len(MAILS)} {sum(len(m) for m in MAILS)}\r\n".encode()
            elif cmd == "LIST":
                response = f"+OK {len(MAILS)} messages\r\n".encode()
                for i, mail in enumerate(MAILS, 1):
                    response += f"{i} {len(mail)}\r\n".encode()
                response += b".\r\n"
            elif cmd == "RETR":
                try:
                    i = int(parts[1]) - 1
                    response = b"+OK message follows\r\n" + MAILS[i].encode() + b"\r\n.\r\n"
                except (IndexError, ValueError):
                    response = b"-ERR invalid message number\r\n"
            elif cmd == "QUIT":
                f.write(b"+OK goodbye\r\n"); f.flush()
                break
            else:
                response = b"-ERR unsupported command\r\n"
            f.write(response); f.flush()
