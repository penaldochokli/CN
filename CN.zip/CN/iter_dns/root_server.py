import socket

s = socket.socket()
s.bind(('localhost', 12001))
s.listen(5)

print('Root Server waiting...')

while True:
    c, addr = s.accept()
    domain = c.recv(1024).decode()

    print('Root received:', domain)
    c.send('TLD server referral'.encode())
    c.close()