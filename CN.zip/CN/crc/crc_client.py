import socket

def crc(data, generator):
    data = list(data + "0" * (len(generator) - 1))
    generator = list(generator)

    for i in range(len(data) - len(generator) + 1):
        if data[i] == '1':
            for j in range(len(generator)):
                data[i + j] = str(
                    int(data[i + j]) ^ int(generator[j])
                )

    return ''.join(data[-(len(generator) - 1):])

  
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(("127.0.0.1", 5001))

data = input("Enter binary data: ")
generator = input("Enter generator: ")

remainder = crc(data, generator)

print("CRC:", remainder)

frame = data + remainder

error = input("Introduce error? (y/n): ")

if error == "y":  
    frame = list(frame)

    # Change one bit
    frame[0] = '1' if frame[0] == '0' else '0'

    frame = ''.join(frame)

print("Transmitted Frame:", frame)

client.send(frame.encode())
client.send(generator.encode())

result = client.recv(1024).decode()

print("Server:", result)

client.close()
