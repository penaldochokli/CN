
import simpy
import random
import time

NUM_FRAMES = 10
TRANSMISSION_DELAY = 1
PROCESSING_DELAY = 0.2
ERROR_PROBABILITY = 0.3


# Calculate CRC remainder
def crc(data, generator):
    bits = list(data + "0" * (len(generator) - 1))

    for i in range(len(data)):
        if bits[i] == "1":
            for j in range(len(generator)):
                bits[i + j] = str(
                    int(bits[i + j]) ^ int(generator[j])
                )

    return "".join(bits[-(len(generator) - 1):])


# Verify received frame
def crc_check(frame, generator):
    bits = list(frame)

    for i in range(len(frame) - len(generator) + 1):
        if bits[i] == "1":
            for j in range(len(generator)):
                bits[i + j] = str(
                    int(bits[i + j]) ^ int(generator[j])
                )

    remainder = "".join(bits[-(len(generator) - 1):])

    return remainder == "0" * (len(generator) - 1)


# Sender process
def sender(env, channel, data, generator, stats):
    for i in range(NUM_FRAMES):
        remainder = crc(data, generator)
        frame = data + remainder

        # Introduce a random transmission error
        error = random.random() < ERROR_PROBABILITY

        if error:
            bits = list(frame)
            bits[0] = "1" if bits[0] == "0" else "0"
            frame = "".join(bits)
            stats["errors_introduced"] += 1

        stats["sent"] += 1
        send_time = env.now

        print(
            f"Time: {env.now:.2f}s | "
            f"Sending Frame {i + 1}: {frame}"
        )

        # Simulate transmission
        yield env.timeout(TRANSMISSION_DELAY)

        yield channel.put((frame, send_time, error))

        # Interval between frames
        yield env.timeout(0.5)


# Receiver process
def receiver(env, channel, generator, stats):
    while True:
        frame, send_time, error = yield channel.get()

        # Simulate receiver processing
        yield env.timeout(PROCESSING_DELAY)

        stats["received"] += 1
        delay = env.now - send_time
        stats["total_delay"] += delay

        if crc_check(frame, generator):
            stats["accepted"] += 1
            result = "Frame Accepted - No Error"
        else:
            stats["rejected"] += 1
            result = "Frame Rejected - Error Detected"

            if error:
                stats["errors_detected"] += 1

        print(
            f"Time: {env.now:.2f}s | "
            f"Delay: {delay:.2f}s | {result}"
        )


# Main program
data = input("Enter binary data: ").strip()
generator = input("Enter generator polynomial: ").strip()

if (
    not data
    or not generator
    or len(generator) < 2
    or data[0] not in "01"
    or any(bit not in "01" for bit in data)
    or any(bit not in "01" for bit in generator)
    or generator[0] != "1"
    or "1" not in generator[1:]
):
    print("Invalid binary data or generator polynomial.")

else:
    random.seed(42)

    stats = {
        "sent": 0,
        "received": 0,
        "accepted": 0,
        "rejected": 0,
        "errors_introduced": 0,
        "errors_detected": 0,
        "total_delay": 0
    }

    env = simpy.Environment()
    channel = simpy.Store(env)

    # Start processes
    env.process(receiver(env, channel, generator, stats))
    sender_process = env.process(
        sender(env, channel, data, generator, stats)
    )

    start = time.perf_counter()

    # Finish after all frames are received
    def finish():
        yield sender_process
        while stats["received"] < NUM_FRAMES:
            yield env.timeout(0.01)

    env.run(until=env.process(finish()))

    execution_time = time.perf_counter() - start

    # Performance report
    print("\n====== PERFORMANCE REPORT ======")
    print("Frames sent:", stats["sent"])
    print("Frames received:", stats["received"])
    print("Frames accepted:", stats["accepted"])
    print("Frames rejected:", stats["rejected"])
    print("Errors introduced:", stats["errors_introduced"])
    print("Errors detected:", stats["errors_detected"])

    if stats["errors_introduced"] > 0:
        rate = (
            stats["errors_detected"]
            / stats["errors_introduced"]
        ) * 100
        print(f"Error detection rate: {rate:.2f}%")

    if stats["received"] > 0:
        avg_delay = stats["total_delay"] / stats["received"]
        print(f"Average delay: {avg_delay:.2f} seconds")

    if env.now > 0:
        throughput = stats["received"] / env.now
        print(f"Throughput: {throughput:.2f} frames/second")

    print(f"Simulation time: {env.now:.2f} seconds")
    print(f"Actual execution time: {execution_time:.6f} seconds")
