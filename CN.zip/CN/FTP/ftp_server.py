import socket, os

HOST, PORT = "127.0.0.1", 2121  # demo port; FTP control commonly uses 21
ROOT = "ftp_demo_files"
os.makedirs(ROOT, exist_ok=True)
with open(os.path.join(ROOT, "welcome.txt"), "w", encoding="utf-8") as f:
    f.write("Hello from FTP demo server.\n")

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT)); s.listen(1)
    print(f"FTP-like demo server listening on {HOST}:{PORT}; files in {ROOT}/")
    conn, addr = s.accept()
    with conn:
        f = conn.makefile("rwb")
        f.write(b"220 FTP demo ready\r\n"); f.flush()
        while True:
            line = f.readline().decode(errors="replace").strip()
            if not line: break
            parts = line.split(maxsplit=1); cmd = parts[0].upper()
            name = parts[1] if len(parts) > 1 else ""
            if cmd == "LIST":
                names = os.listdir(ROOT)
                f.write(("200 " + (", ".join(names) if names else "(empty)") + "\r\n").encode())
            elif cmd == "GET":
                path = os.path.join(ROOT, os.path.basename(name))
                if os.path.isfile(path):
                    content = open(path, "rb").read()
                    f.write(f"150 {len(content)}\r\n".encode()); f.write(content); f.write(b"\nEND\n")
                else: f.write(b"550 file not found\r\n")
            elif cmd == "PUT":
                # One-line text upload: PUT filename|content
                if "|" not in name:
                    f.write(b"501 use PUT filename|text\r\n")
                else:
                    filename, content = name.split("|", 1)
                    path = os.path.join(ROOT, os.path.basename(filename))
                    with open(path, "w", encoding="utf-8") as out: out.write(content)
                    f.write(b"226 upload complete\r\n")
            elif cmd == "QUIT":
                f.write(b"221 bye\r\n"); f.flush(); break
            else: f.write(b"502 unsupported command\r\n")
            f.flush()
