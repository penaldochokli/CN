import simpy, random
random.seed(11)

def transfer(env, stats, n):
    start = env.now
    size_kb = random.randint(10, 100)
    print(f"{env.now:.1f}s Client {n}: connect and request file ({size_kb} KB)")
    yield env.timeout(0.2)
    transfer_time = size_kb / 80.0
    yield env.timeout(transfer_time)
    print(f"{env.now:.1f}s Client {n}: transfer complete")
    stats["ok"] += 1; stats["bytes_kb"] += size_kb; stats["time"] += env.now-start

env = simpy.Environment(); stats = {"ok": 0, "bytes_kb": 0, "time": 0.0}
for n in range(1, 4): env.process(transfer(env, stats, n))
env.run()
print("Completed transfers:", stats["ok"], "Total data:", stats["bytes_kb"], "KB",
      "Average transfer time:", round(stats["time"]/stats["ok"], 2), "s")
