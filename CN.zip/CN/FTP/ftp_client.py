import socket

HOST, PORT = "127.0.0.1", 2121
with socket.create_connection((HOST, PORT)) as s:
    f = s.makefile("rwb")
    print(f.readline().decode().strip())
    for cmd in ["LIST", "GET welcome.txt", "PUT notes.txt|Uploaded by the FTP client", "LIST", "QUIT"]:
        print(">", cmd)
        f.write((cmd + "\r\n").encode()); f.flush()
        line = f.readline()
        if not line: break
        print(line.decode(errors="replace").rstrip())
        if cmd.startswith("GET ") and line.startswith(b"150"):
            while True:
                data = f.readline()
                if data == b"\nEND\n" or data.endswith(b"END\n"): break
                if not data: break
                print(data.decode(errors="replace").rstrip())
