import socket

DNS = {
    'google.com': '142.250.183.14',
    'yahoo.com': '74.6.143.25'
}

s = socket.socket()
s.bind(('localhost', 12103))
s.listen(5)

print('Authoritative Server waiting...')

while True:
    c, addr = s.accept()
    domain = c.recv(1024).decode()

    ip = DNS.get(domain, 'Not Found')
    print(domain, '->', ip)

    c.send(ip.encode())
    c.close()