import simpy

DNS = {
    'google.com': '142.250.183.14',
    'yahoo.com': '74.6.143.25'
}


def local_dns(env, domain, data):
    data['step'] += 1
    print('Time:', env.now, '| Step:', data['step'],
          '| Local DNS received:', domain)

    yield env.timeout(1)

    ip = yield env.process(root(env, domain, data))
    return ip


def root(env, domain, data):
    data['step'] += 1
    print('Time:', env.now, '| Step:', data['step'],
          '| Root server:', domain)

    yield env.timeout(1)

    ip = yield env.process(tld(env, domain, data))
    return ip


def tld(env, domain, data):
    data['step'] += 1
    print('Time:', env.now, '| Step:', data['step'],
          '| TLD server:', domain)

    yield env.timeout(1)

    ip = yield env.process(auth(env, domain, data))
    return ip


def auth(env, domain, data):
    data['step'] += 1
    print('Time:', env.now, '| Step:', data['step'],
          '| Authoritative server:', domain)

    yield env.timeout(1)
    return DNS.get(domain, 'Not Found')


def client(env, domain):
    start = env.now
    data = {'step': 0}

    print('\nClient requests:', domain)

    ip = yield env.process(local_dns(env, domain, data))

    total = env.now - start

    print('IP Address:', ip)
    print('Total Time:', total, 'seconds')
    print('Total Steps:', data['step'])
    print('Performance:', round(data['step'] / total, 2),
          'steps/second')
    print('-' * 35)


env = simpy.Environment()

env.process(client(env, 'google.com'))
env.process(client(env, 'yahoo.com'))
env.process(client(env, 'unknown.com'))

env.run()