import socket
import threading


def client(domain):
    s = socket.socket()
    s.connect(('localhost', 12100))
    s.send(domain.encode())

    ip = s.recv(1024).decode()
    print(domain, '->', ip)

    s.close()


domains = ['google.com', 'yahoo.com', 'unknown.com']

for domain in domains:
    threading.Thread(target=client, args=(domain,)).start()