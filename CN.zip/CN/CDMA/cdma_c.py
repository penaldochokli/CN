
import socket

c = socket.socket()
c.connect(('localhost', 1233))

data = int(input("Enter data bit (1 or -1): "))
print("Enter 4-chip sequence (orthogonal codes)")
code = list(map(int, input().split()))

if len(code) != 4 or any(x not in (-1, 1) for x in code):
    print("Invalid chipping sequence")
    c.close()
    exit()

c.send((str(data) + " " + " ".join(map(str, code))).encode())

c.close()