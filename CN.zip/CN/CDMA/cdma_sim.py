import simpy

def add(a, b):
    return [x + y for x, y in zip(a, b)]

def multiply(a, b):
    return [x * y for x, y in zip(a, b)]

def client(env, name, data, code, channel, signals):
    print(f"{name} sending data: {data}")
    yield env.timeout(1)

    signal = [data * x for x in code]
    signals.append(signal)

    print(f"{name} chipping sequence: {code}")
    print(f"{name} transmitted signal: {signal}")

    yield channel.put(signal)


def server(env, channel, code1, code2):
    signal1 = yield channel.get()
    signal2 = yield channel.get()

    print("\nServer received both signals")

    combined = add(signal1, signal2)
    print("Combined signal:", combined)

    result1 = sum(multiply(combined, code1)) // len(code1)
    result2 = sum(multiply(combined, code2)) // len(code2)

    print("Decoded data from Client 1:", result1)
    print("Decoded data from Client 2:", result2)


env = simpy.Environment()
channel = simpy.Store(env)
signals = []

data1 = 1
data2 = -1

code1 = [1, 1, 1, 1]
code2 = [1, -1, 1, -1]

env.process(server(env, channel, code1, code2))
env.process(client(env, "Client 1", data1, code1, channel, signals))
env.process(client(env, "Client 2", data2, code2, channel, signals))

env.run()
