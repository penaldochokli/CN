import socket

c = socket.socket()
c.connect(('localhost', 1225))

data = input("Enter data bits: ")

# Bit Stuffing
stuffed = ""
count = 0

for bit in data:
    stuffed += bit

    if bit == '1':
        count += 1
    else:
        count = 0

    if count == 5:
        stuffed += '0'
        count = 0

print("Stuffed data:", stuffed)

c.send(stuffed.encode())

result = c.recv(1024).decode()
print("Received destuffed data:", result)

c.close()