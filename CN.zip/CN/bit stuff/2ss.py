import simpy

def sender(env, channel, data):
    stuffed = ""
    count = 0

    for bit in data:
        stuffed += bit

        if bit == '1':
            count += 1
        else:
            count = 0

        if count == 5:
            stuffed += '0'
            count = 0

    print("Sender: Original data =", data)
    print("Sender: Stuffed data  =", stuffed)

    yield env.timeout(1)
    yield channel.put(stuffed)


def receiver(env, channel):
    stuffed = yield channel.get()

    destuffed = ""
    count = 0
    i = 0

    while i < len(stuffed):
        bit = stuffed[i]
        destuffed += bit

        if bit == '1':
            count += 1
        else:
            count = 0

        if count == 5:
            i += 1  # Skip the stuffed zero
            count = 0

        i += 1

    print("Receiver: Received stuffed data =", stuffed)
    print("Receiver: Destuffed data        =", destuffed)


env = simpy.Environment()
channel = simpy.Store(env)

data = input("Enter data bits: ")

env.process(sender(env, channel, data))
env.process(receiver(env, channel))

env.run()