import simpy
import random

random.seed(10)

N = 5
CW_MIN, CW_MAX = 4, 16
SLOT = 0.001
TX_TIME = 0.01
MAX_RETRIES = 4
SIM_TIME = 10

def node(env, name, channel, stats):
    while True:
        yield env.timeout(random.expovariate(20))
        stats["generated"] += 1
        print(f"{env.now:.3f}: {name} packet generated")

        cw, retry = CW_MIN, 0

        while retry <= MAX_RETRIES:
            backoff = random.randrange(cw)
            print(name, "Backoff:", backoff)

            while backoff > 0:
                if channel["busy"]:
                    yield env.timeout(SLOT)
                else:
                    yield env.timeout(SLOT)
                    if not channel["busy"]:
                        backoff -= 1

            yield env.timeout(0.0001)

            if channel["busy"]:
                stats["collisions"] += 1
                retry += 1
                stats["retries"] += 1
                cw = min(cw * 2, CW_MAX)
                print(name, "Collision, retry:", retry)
                continue

            channel["busy"] = True
            print(name, "Transmitting")
            yield env.timeout(TX_TIME)
            channel["busy"] = False
            stats["success"] += 1
            print(name, "Transmission successful")
            break

        if retry > MAX_RETRIES:
            stats["dropped"] += 1
            print(name, "Packet dropped")

env = simpy.Environment()
channel = {"busy": False}
stats = {"generated": 0, "success": 0,
         "collisions": 0, "retries": 0, "dropped": 0}

for i in range(N):
    env.process(node(env, f"N{i+1}", channel, stats))

print("CSMA/CA Simulation Started")
env.run(until=SIM_TIME)

print("\n--- RESULTS ---")
for key, value in stats.items():
    print(key.capitalize(), ":", value)
print("CSMA/CA Simulation Completed")