import simpy, random
random.seed(10)
objects = {"sysName": "LabRouter", "sysLocation": "Computer Lab", "sysUpTime": "3600 seconds"}

def manager(env, stats, name):
    start = env.now
    print(f"{env.now:.1f}s SNMP manager: GET {name}")
    yield env.timeout(random.uniform(0.1, 0.4))
    if name in objects:
        print(f"{env.now:.1f}s Agent: RESPONSE {name}={objects[name]}")
        stats["ok"] += 1
    else:
        print(f"{env.now:.1f}s Agent: ERROR unknown object {name}")
        stats["fail"] += 1
    stats["delay"] += env.now-start

env = simpy.Environment(); stats = {"ok": 0, "fail": 0, "delay": 0.0}
for name in ["sysName", "sysLocation", "sysUpTime", "unknownObject"]:
    env.process(manager(env, stats, name))
env.run()
total = stats["ok"] + stats["fail"]
print("GET requests:", total, "Successful:", stats["ok"], "Failed:", stats["fail"],
      "Average response time:", round(stats["delay"]/total, 2), "s")
