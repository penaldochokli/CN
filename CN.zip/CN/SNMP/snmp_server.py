import socket

HOST, PORT = "127.0.0.1", 1161  # demo port; SNMP commonly uses UDP 161
device = {"sysName": "LabRouter", "sysLocation": "Computer Lab", "sysUpTime": "3600 seconds"}
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    s.bind((HOST, PORT))
    print(f"SNMP-like UDP agent listening on {HOST}:{PORT}")
    while True:
        data, addr = s.recvfrom(1024)
        request = data.decode(errors="replace").strip()
        print("GET request:", request, "from", addr)
        if request in device:
            reply = f"OK|{request}|{device[request]}"
        else:
            reply = f"ERROR|Unknown OID/name: {request}"
        s.sendto(reply.encode(), addr)
        if request.upper() == "QUIT":
            break
